#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar 26 11:38:31 2020

@author: Rajiv Sambasivan
"""

from abc import ABC

class Networkx_Adapter_Base(ABC):

    def create_networkx_graph():
        pass
